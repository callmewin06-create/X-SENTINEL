# GHI CH? CH?N M?U & K?T QU? TH?C NGHI?M T?NH BODMAS (SELECTION NOTES)

D? ?n: **X-SENTINEL: Cross-View Semantic Backdoor Detection in Malware Classifiers**  
M?i tr??ng th?c thi: **M?y ?o Kali Linux (x86_64, Docker Container isolate)**  
Ng?y th?c hi?n: **2026-10-22**

---

## 1. NGU?N M?U & B?I C?NH D? LI?U

- **Ngu?n m?u malware**: ???c c?p t? b? d? li?u BODMAS (`BODMAS_disarmed_malware_binaries.zip`, dung l??ng n?n 67.9 GiB / 72.9 GB).
  - T?ng s? file gi?i n?n th?c t?: **57.293 t?p PE** (??t trong th? m?c `altered/`).
  - T?nh tr?ng v? hi?u h?a (**Disarmed**): C?c m?u ?? ???c x? l? v? hi?u h?a ? ph?n PE header / entry point t? b? d? li?u g?c BODMAS nh?m m?c ??ch an to?n, ch? ph?c v? tr?ch xu?t ??c tr?ng t?nh (Static Analysis) b?ng b? ??c LIEF (v0.16.6), tuy?t ??i kh?ng bao gi? th?c thi nh? ph?n.
  - Nh?n khai b?o: `malware` (Ngu?n: `teacher-supplied BODMAS; see selection_notes.md`, lo?i x?c minh: `USER_DECLARED_NOT_INDEPENDENTLY_VERIFIED`).
- **Ngu?n m?u l?nh (Benign)**: T?p `ReviewedBenignFixture.exe` do d? ?n t? bi?n d?ch t? m? ngu?n C# (`ReviewedBenignFixture.cs`) ?? ???c r? so?t (kh?ng c? h?m can thi?p m?ng/t?p tin).
  - K?ch th??c: 4.096 byte.
  - SHA-256 byte th?c t?: `72524cf3d72fe935d482300d4b9d7414dbea7ab9786b76723f3a7132331e4485`.
  - Nh?n khai b?o: `benign` (Ngu?n: `reviewed self-built benign fixture; see selection_notes.md`).

---

## 2. QUY T?C & PH??NG PH?P CH?N M?U

Tu?n th? nghi?m ng?t theo ??c t? chu?n trong `docs/HUONG_DAN_BODMAS_KALI_2026_10_19.md`:

1. **L??t th? nghi?m ???ng truy?n (Smoke Test - `smoke1`)**:
   - Ch?n 1 m?u l?nh `ReviewedBenignFixture.exe` ??a v?o `samples/smoke/`.
   - M?c ??ch: X?c th?c tr?n v?n lu?ng tr?ch xu?t t?nh, n?p model, suy lu?n x?c su?t v? ghi nh?n 3 t?p ??u ra (`manifest.json`, `results.csv`, `summary.json`) tr?n c? 4 bundle m? kh?ng g?p s? c? runtime.
2. **L??t ki?m th? m?u l?nh (Benign Test - `benign1`)**:
   - Ch?n 1 m?u l?nh ki?m so?t ??a v?o `samples/benign/`.
   - Ch?y tr?n 4 bundle ?? ??i chi?u t? l? b?o nh?m (False Positive) c?a b? ph?n lo?i v? d?u hi?u trigger.
3. **L??t Pilot (Pilot Run - `pilot20`)**:
   - Ch?n ng?u nhi?n c? th? t?i l?p **20 m?u** t? to?n b? 57.293 t?p PE malware b?ng thu?t to?n b?c th?m seed c? ??nh (`seed = 17`) th?ng qua script chu?n h?a `check_bodmas_static.py`.
   - To?n b? 4 bundle d?ng chung m?t `manifest.json` (SHA-256: `221e49b7aa980a3a1a89f16c71b0a3d61c2b4d2da1fb3060807532396039f704`).
4. **L??t ki?m tra ch?nh (Main Run - `bodmas200`)**:
   - Ch?n ng?u nhi?n c? th? t?i l?p **200 m?u** t? kho m?u PE malware v?i `seed = 17`.
   - Kh?i t?o manifest g?c ? l??t `bodmas200_2018_reduced` v? t?i s? d?ng 100% manifest n?y cho 3 bundle c?n l?i (`2018_full`, `2024_reduced`, `2024_full`), v?i SHA-256 manifest: `a04d84c3fdfc4deea08f009e15e1af5b38cc4e36b2f613a0eab7cebf26dff9fc`.

---

## 3. T?NG H?P K?T QU? C?C L??T CH?Y

### 3.1. L??t ch?nh `bodmas200` (200 m?u malware BODMAS)

| Bundle Alias | Dataset | Variant | Method | T?ng ch?n | X? l? OK | L?i Parse | MALWARE | BENIGN | C?nh b?o Trigger |
| :--- | :--- | :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **2018-reduced** | EMBER2018 | reduced | X_primary_reduced | 200 | 175 | 25 | 162 | 13 | 2 (1.0%) |
| **2018-full** | EMBER2018 | full | X_primary_full | 200 | 175 | 25 | 162 | 13 | 2 (1.0%) |
| **2024-reduced** | EMBER2024 | reduced | X_primary_reduced | 200 | 175 | 25 | 175 | 0 | 0 (0.0%) |
| **2024-full** | EMBER2024 | full | X_primary_full | 200 | 175 | 25 | 175 | 0 | 0 (0.0%) |

*Ghi ch?*:
- 25 m?u b? l?i `parse_failed` do c?c c?u tr?c nh? ph?n b? h?ng trong qu? tr?nh v? hi?u h?a (corrupted relocation, section header out-of-bound). To?n b? l?i ???c gi? nguy?n v?n trong `results.csv` theo nguy?n t?c trung th?c khoa h?c, kh?ng b? lo?i b?.
- M? h?nh EMBER2024 nh?n di?n ch?nh x?c 100% c?c m?u ??c ???c (175/175) l? `MALWARE`.
- M? h?nh EMBER2018 nh?n di?n 162/175 m?u ??c ???c l? `MALWARE`, 13 m?u l? `BENIGN`.

### 3.2. L??t Pilot `pilot20` (20 m?u malware BODMAS)

| Bundle Alias | Dataset | Variant | Method | T?ng ch?n | X? l? OK | L?i Parse | MALWARE | BENIGN | C?nh b?o Trigger |
| :--- | :--- | :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **2018-reduced** | EMBER2018 | reduced | X_primary_reduced | 20 | 17 | 3 | 15 | 2 | 0 (0.0%) |
| **2018-full** | EMBER2018 | full | X_primary_full | 20 | 17 | 3 | 15 | 2 | 0 (0.0%) |
| **2024-reduced** | EMBER2024 | reduced | X_primary_reduced | 20 | 17 | 3 | 17 | 0 | 0 (0.0%) |
| **2024-full** | EMBER2024 | full | X_primary_full | 20 | 17 | 3 | 17 | 0 | 0 (0.0%) |

---

## 4. CHI TI?T B? M?U MINH H?A DEMO (2?3 M?U MALWARE & FILE L?NH)

D??i ??y l? chi ti?t c?c m?u ??i di?n ???c tr?ch xu?t t? d? li?u th?c t? ?? ch?y qua c? 4 bundle, d?ng ?? tr?nh chi?u v? b?o c?o demo:

### 4.1. M?u Malware 1
- **???ng d?n**: `altered/0175a338a55e526eb4dbdfe2802781af659ea403310199e9c14eae7e32cf0330.exe`
- **K?ch th??c**: 96.611 byte
- **SHA-256**: `f6cf8096096c68244fb05cff89442a87ef2b3b5eb12726f09bda4d7940b9a320`
- **K?t qu? quan s?t tr?n 4 bundle**:

| Bundle | Ph?n lo?i | X?c su?t Malware | ?i?m Score | Ng??ng (Threshold) | C?nh b?o Trigger | Tr?ng th?i |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| `2018-reduced` | **MALWARE** | 83.32% | 0.599 | 0.950 | False | ok |
| `2018-full` | **MALWARE** | 83.32% | 0.164 | 0.953 | False | ok |
| `2024-reduced` | **MALWARE** | 98.28% | 0.662 | 0.943 | False | ok |
| `2024-full` | **MALWARE** | 98.28% | 0.355 | 0.956 | False | ok |

### 4.2. M?u Malware 2
- **???ng d?n**: `altered/02ced4653600de405c3aa821a9f576d8a3b902e05106834271fb9026e1c57469.exe`
- **K?ch th??c**: 273.981 byte
- **SHA-256**: `7b2eb54fb371e7b70dbe5629843bb6f06a1e8f49c9cbd7a1526625dc4f66627b`
- **K?t qu? quan s?t tr?n 4 bundle**:

| Bundle | Ph?n lo?i | X?c su?t Malware | ?i?m Score | Ng??ng (Threshold) | C?nh b?o Trigger | Tr?ng th?i |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| `2018-reduced` | **MALWARE** | 92.76% | 0.609 | 0.950 | False | ok |
| `2018-full` | **MALWARE** | 92.76% | 0.174 | 0.953 | False | ok |
| `2024-reduced` | **MALWARE** | 99.35% | 0.654 | 0.943 | False | ok |
| `2024-full` | **MALWARE** | 99.35% | 0.355 | 0.956 | False | ok |

### 4.3. M?u Malware 3
- **???ng d?n**: `altered/04fd4db1c34dba0f545952c8ae0948b259d7133000e7278034c9f53cf1ef08e4.exe`
- **K?ch th??c**: 728.064 byte
- **SHA-256**: `437a910fe416885cc1f084f8134ebeba6f94d11e4f50130168906f62d238dfdb`
- **K?t qu? quan s?t tr?n 4 bundle**:

| Bundle | Ph?n lo?i | X?c su?t Malware | ?i?m Score | Ng??ng (Threshold) | C?nh b?o Trigger | Tr?ng th?i |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| `2018-reduced` | **MALWARE** | 90.93% | 0.526 | 0.950 | False | ok |
| `2018-full` | **MALWARE** | 90.93% | 0.084 | 0.953 | False | ok |
| `2024-reduced` | **MALWARE** | 99.89% | 0.465 | 0.943 | False | ok |
| `2024-full` | **MALWARE** | 99.89% | 0.166 | 0.956 | False | ok |

### 4.4. M?u L?nh (Reviewed Benign Fixture)
- **T?n t?p**: `ReviewedBenignFixture.exe`
- **K?ch th??c**: 4.096 byte
- **SHA-256**: `72524cf3d72fe935d482300d4b9d7414dbea7ab9786b76723f3a7132331e4485`
- **K?t qu? quan s?t tr?n 4 bundle**:

| Bundle | Ph?n lo?i | X?c su?t Malware | ?i?m Score | Ng??ng (Threshold) | C?nh b?o Trigger | Nh?n x?t |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| `2018-reduced` | **BENIGN** | 4.43% | 0.939 | 0.950 | False | Ph?n lo?i ??ng nh?n file l?nh |
| `2018-full` | **BENIGN** | 4.43% | 0.921 | 0.953 | False | Ph?n lo?i ??ng nh?n file l?nh |
| `2024-reduced` | **MALWARE** | 95.79% | 0.419 | 0.943 | False | B?o nh?m (False Positive c?a model V3) |
| `2024-full` | **MALWARE** | 95.79% | 0.099 | 0.956 | False | B?o nh?m (False Positive c?a model V3) |

---

## 5. PH?M VI & GI?I H?N K? THU?T

1. To?n b? c?c th? nghi?m ch? ch?ng minh quy tr?nh ph?n t?ch t?nh (PE parsing -> tr?ch xu?t ??c tr?ng -> suy lu?n LightGBM) v?n h?nh ch?nh x?c v? an to?n tr?n m?i tr??ng m?y ?o Kali Linux.
2. Vi?c m? h?nh d? ?o?n `MALWARE` ho?c kh?ng k?ch ho?t trigger tr?n c?c m?u BODMAS kh?ng ch?ng minh c?c m?u n?y ?? ???c c?y backdoor ho?c trigger ho?t ??ng sau khi v? hi?u h?a binary.
3. Kh?ng th?c hi?n ch?y nh? ph?n ho?c ch?nh s?a payload c?a b?t k? file m? ??c n?o.
