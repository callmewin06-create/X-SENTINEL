# Hướng dẫn Quân ghép bài

Không chèn nguyên gói này vào cuối bài. Thầy yêu cầu rút gọn và đổi cách trình bày; thêm liên tiếp nhiều bảng sẽ làm vấn đề dài dòng nặng hơn.

| Vị trí theo nội dung | Việc sửa | Nguồn |
|---|---|---|
| Tiêu đề và Abstract | Thống nhất tiêu đề mô tả đúng tín hiệu; Abstract nói rõ feature-space ngay đầu | PAPER_INSERTS_EN.md |
| Cuối Introduction | Dùng bốn đóng góp, gồm cả phát hiện giới hạn của phương pháp | Contributions |
| Threat Model & Scope | Đặt Reduced làm thiết lập chính; phân biệt model sạch của evaluator với quyền của defender | Scope và resource_access_comparison.csv |
| Phương pháp và protocol | Bổ sung SHAP-IF, quy tắc ngưỡng, các thí nghiệm bổ sung; giữ 54 cấu hình gốc tách khỏi hai seed mới | Methods và protocols/ |
| Kết quả chính | Giữ bảng kết quả gốc có ngưỡng calibration; thêm bảng so sánh cùng FPR, Cross/paired evasion và adaptive | same_fpr_comparison.csv, cross_confirmation_summary.csv, adaptive_summary.csv |
| Chi phí dữ liệu sạch | Đặt hai hình budget cạnh nhau hoặc thành hai panel; giải thích điểm Full tốt hơn Shadow và điểm vẫn thua Reduced | figures/clean_budget_*.pdf |
| Biến thiên kết quả | Nêu tổng 5 lượt thử, 4 đạt; đưa bảng từng seed vào phụ lục nếu thiếu chỗ | ember2024_seed_runs.csv và ember2024_seed_variability.csv |
| Bối cảnh phòng thủ tập train | Một đoạn trong thân bài; bảng 4 dòng có thể đặt phụ lục | training_defense_results.csv |
| Limitations | Gom Cross/adaptive, feature-space, giới hạn dữ liệu/seed, lỗi fixture và dữ liệu đã được quan sát | Consolidated limitations |
| Phụ lục kỹ thuật riêng | Chuyển Docker, PostgreSQL, UI, restore, upload và test phần mềm ra khỏi mạch nghiên cứu | Nội dung hệ thống cũ |

Các hình ROC chi tiết và CSV đầy đủ có thể đặt ở phụ lục/artifact. Không cần nhét tất cả vào thân bài. Chưa đánh số bảng/hình trong gói vì thứ tự còn phụ thuộc bản ghép cuối.

Đơn vị: tỷ lệ trong CSV thường ở thang 0–1; bảng Markdown có dấu % đã nhân 100. Change pp là điểm phần trăm. Standardized pAUC vẫn ở thang 0–1. Runs là số model/cấu hình, không phải số file độc lập.

Chỉ copy phần văn bản nghiên cứu phù hợp từ PAPER_INSERTS_EN.md. Dòng hướng dẫn biên tập, README, lỗi v1/v2 và trạng thái đồng đội là tài liệu nội bộ, không đưa vào narrative của bài báo.

Trước khi xuất bản cuối: kiểm lại số bảng/hình, tất cả lời dẫn trong thân bài, ký hiệu công thức trong PDF, nguồn chính thức do Phú rà và bằng chứng binary do Phúc gửi. Gói này chưa xác nhận bố cục bản Word cuối.
