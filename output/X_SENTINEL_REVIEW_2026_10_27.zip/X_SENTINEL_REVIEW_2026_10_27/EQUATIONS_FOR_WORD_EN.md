# Equations checked against the current primary code

Source: src/xsentinel/detection/components.py and src/xsentinel/detection/calibration.py. Insert in Word's equation editor using LaTeX input, convert to professional layout, then inspect the exported PDF. This file supplies notation; it does not verify Word rendering or assign final equation numbers.

Let phi_j be signed native SHAP contributions to the malware raw margin, excluding the bias column. Let D(x) be the sum of absolute contributions over all features. The three feature views form the schema's partition. p_main and p_Beh are malware probabilities, not SHAP values.

```latex
D(x)=\sum_{j=1}^{d}|\phi_j(x)|
```

For D(x)>10^{-9}:

```latex
\mathrm{VMC}(x)=\max_{v\in\mathcal{V}}\frac{\sum_{j\in v}|\phi_j(x)|}{D(x)}
```

```latex
\mathrm{BGS}(x)=(1-p_{\mathrm{main}}(x))\frac{\max(0,\sum_{j\in\mathrm{Beh}}\phi_j(x))}{D(x)}
```

Set VMC and BGS to zero when D(x)<=10^{-9}, matching the implementation. BGS takes the positive part after summing signed Behavioral contributions; it does not sum only positive individual contributions.

```latex
\mathrm{BPG}(x)=\max(0,p_{\mathrm{Beh}}(x_{\mathrm{Beh}})-p_{\mathrm{main}}(x))
```

For a component k, use its own benign reference empirical CDF. The less-than-or-equal comparison includes ties.

```latex
\widehat{F}_k(t)=\frac{1}{n_r}\sum_{i=1}^{n_r}\mathbf{1}\{S_k(x_i^{\mathrm{ref}})\le t\},\qquad n_r=500
```

```latex
X_R(x)=\frac{\widehat{F}_{\mathrm{VMC}}(\mathrm{VMC}(x))+\widehat{F}_{\mathrm{BGS}}(\mathrm{BGS}(x))}{2}
```

```latex
X_F(x)=\frac{\widehat{F}_{\mathrm{VMC}}(\mathrm{VMC}(x))+\widehat{F}_{\mathrm{BPG}}(\mathrm{BPG}(x))}{2}
```

With ascending calibration scores s_(1),...,s_(n_c), use the one-based order statistic below. It is s_(1980) when n_c=2000 and alpha=0.01.

```latex
\tau=s_{(n_c-\lfloor\alpha n_c\rfloor)},\qquad \mathrm{alert}(x)=\mathbf{1}\{S(x)>\tau\}
```

Reference ranking uses <=; alerting uses >. These operators serve different purposes and must not be made identical for visual consistency. The calibration guarantee is at most20 of2000 calibration scores strictly above the threshold; it is not a guarantee of at most1% alerts on a new final pool.
