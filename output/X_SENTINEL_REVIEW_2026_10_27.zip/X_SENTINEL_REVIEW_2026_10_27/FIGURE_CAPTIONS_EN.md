# Figure captions

## Low-FPR curves

Mean attainable TPR against empirical benign FPR budgets up to 1%, computed separately within each frozen model configuration and then averaged. Positives are successful-eligible triggered malware. Tied scores remain inseparable; step operating points are not interpolated. These are retrospective final-pool comparisons. The legend reports the number of original confirmed configurations: 12 for EMBER2018 restricted, 3 for EMBER2024 restricted and 9 for EMBER2024 Cross. The two additional seed attempts are reported separately. Standardized partial AUC in the tables uses its stated sklearn definition rather than the plotted step area.

## Clean-data budget curves

Mean low-FPR TPR on the original confirmed restricted cohorts as trusted labelled fit access increases. The horizontal axis is logarithmic; points are 1000, 5000, 10000, 50000 and 200000 fit records, with nested class-balanced subsets. Suspicious models and source pools are fixed. The 500 benign reference and 2000 benign calibration records are separate from this fit budget. Shadow requires no rank reference; the Reduced horizontal line requires no auxiliary labelled fit set. BPG denotes Behavioral probability gap. The original Behavioral and Shadow training-round settings differ, so this is a data-access comparison, not a compute-matched comparison.

## Same-FPR bar summary

Mean TPR at attainable empirical FPR no greater than 1%, using the same model/input groups per method. Displayed values are macro means over the original confirmed restricted configurations. The complete CSV also reports actual attained FPR, all nonconfirmed configurations and alternative positive groups. VMC is view mass concentration; BGS is Behavioral-gated SHAP; BPG is Behavioral probability gap.
