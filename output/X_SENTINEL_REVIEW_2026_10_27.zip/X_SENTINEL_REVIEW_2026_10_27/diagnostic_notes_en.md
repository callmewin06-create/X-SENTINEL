# Diagnostic text and editor notes

## Calibration versus final FPR

The 1% target constrains the observed calibration pool, not the final pool. We retain the strict score > threshold rule. Equal scores at the cutoff are not flagged. The supplied diagnostics report counts above and equal to the threshold, unique score counts and the 99th percentile in both pools. Final FPR can exceed the calibration target despite a correctly implemented threshold. Ties constrain attainable operating points, but do not alone prove the cause of an upward final FPR difference. Finite-sample variation and differences between the two benign score distributions remain possible explanations; this analysis does not isolate a causal contribution from each. The same-FPR and partial-AUC tables address ranking comparison separately.

## Score direction

AUROC below 0.5 indicates that the implemented score tends to rank the evaluated positives below benign negatives. This may reveal mismatch between a heuristic and this population; it does not by itself prove a coding sign error. Negating a score reverses its ranking AUC, with tie handling preserved. The negated TADR column is a diagnostic obtained after observing outcomes, not a newly validated defense. STRIP_inverse retains its separately calibrated threshold and is explicitly labelled. Mixing hashed/count feature vectors is a synthetic intervention and need not represent executable-file behavior. SHAP-IF uses its prespecified anomaly orientation without selecting the sign from final performance.

## Timing replacement

The reported timing measurements refer to different execution scopes and input sets: core detector scoring, the small maintenance smoke test, and end-to-end file processing. They should be presented separately. In particular, the observed EMBER2024 Full change from19.28 to27.28 ms is not evidence of an optimization or a confirmed regression mechanism. We have not isolated the cause with a controlled timing experiment. Replace the vague near28 ms wording with the exact named benchmark and its21–32 ms reported range where applicable; do not merge these measurements into one latency claim. Current supplementary training/scoring jobs ran concurrently and their elapsed times are provenance, not replacement latency benchmarks.

## Final Word checklist

- Table IV:17,29,43; additional seeds59,71 belong to the supplemental seed table.
- Table XVII: distinguish175 successfully scored files from200 attempted files; the known2018 Reduced count is2 alerts, not212. Verify against the BODMAS source table before export.
- Table III: use is_pe=0: benign/malware for the count pair.
- The benign fixture called malware is a false classification; explain it in Limitations.
- Rebuild equations with the Word equation editor using proper summation indices and p_Beh(x_Beh), then inspect the exported PDF. Text extraction alone cannot verify the typography.
- Use all fit records consistently as the poisoning denominator:1000/2000/4000 of200000 correspond to0.5/1/2%; the benign fit half has100000 records.
- Remove revision-history and course-rubric prose from the research narrative. Keep engineering history in a separate artifact appendix.

The latest canonical Word and Phuc's binary results have not been supplied. These are editing instructions and evidence notes, not a claim that the final Word has been repaired or visually verified.
