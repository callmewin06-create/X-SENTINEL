# Kết quả để trưởng nhóm giải thích

Không nên nói nhóm đã sửa hết điểm yếu của hệ thống. Nhóm đã bổ sung các phép đánh giá còn thiếu và có bằng chứng rõ hơn về nơi phương pháp dùng được, nơi nó thất bại. Model đang dùng trong ứng dụng không được thay bằng các model thí nghiệm mới.

## 1. Shadow và Full

Khi có 200.000 mẫu đáng tin để huấn luyện, Shadow vẫn là đối chứng rất mạnh. Vì vậy hướng đặt Reduced làm trọng tâm có cơ sở hơn việc khẳng định Full là phương án tốt nhất.

Ở mức 1.000 mẫu fit, Full đạt 33.60% trên nhóm restricted 2018 và 56.24% trên restricted 2024; Shadow tương ứng 16.90% và 51.29%. Đây là recall với trần báo nhầm thực nghiệm 1%, không phải accuracy. Full ở mức này vẫn thua Reduced trên 2018. Full còn dùng thêm 500 mẫu lành reference; không được nói toàn bộ tài nguyên thông tin và thời gian huấn luyện đã ngang nhau.

## 2. Cross và adaptive

Cross 2018 làm chính model sạch bị lừa rất nhiều. So sánh cùng một mẫu trước/sau mới thấy phần sai tăng thêm do model đầu độc dưới 20 điểm phần trăm, nên không đạt tiêu chí xác nhận đã khóa.

Khi cho phép sửa thêm ở nhiều view, tỷ lệ vừa qua được classifier vừa không bị Reduced cảnh báo tăng trung bình từ 44.25% lên 59.50% trên nhóm restricted 2018; từ 36.77% lên 45.02% trên restricted 2024. Đây là kết quả xấu đi đối với phòng thủ. Nhóm Cross 2024 trong 100 ID được chọn đã qua cả hai ngay từ đầu; không được gọi đó là 100% thành công mới do optimizer tìm ra.

## 3. EMBER2024

Đã thêm đúng seed 59 và 71 theo kế hoạch. Seed 71 không qua cutoff ASR 50% ở confirmation. Tổng là 5 lượt thử ở spread 2%, trong đó 4 lượt đạt. Cùng một tập nguồn vẫn được dùng lại; không biến 5 seed thành 5 tập kiểm tra độc lập hoặc nói đã kiểm tra nhiều họ trigger hơn.

## 4. Hai loại Isolation Forest

SHAP-IF theo từng đầu vào dùng 500 mẫu reference để học vùng thường gặp và 2000 mẫu calibration để đặt ngưỡng. Đã chấm đủ 54 cấu hình, gồm cả malware chưa sửa làm đối chứng. Kết quả thấp vẫn được giữ; không đổi chiều điểm theo final để làm baseline đẹp lên.

IF lọc tập train là thí nghiệm khác: có quyền xem tập huấn luyện nghi nhiễm, loại 5000 mẫu rồi huấn luyện lại. Trong hai cấu hình được chọn, nó giảm ASR nhưng vẫn để lại nhiều trường hợp tấn công thành công. Không trộn ASR sau retrain với recall của bộ cảnh báo theo từng file.

## 5. Điều đã kiểm chứng và điều đang chờ

39 kiểm thử hồi quy đã qua. Kiểm toán riêng đối chiếu score, số đếm, ngưỡng, ID, các tập con dữ liệu và 222 tài sản gốc trong manifest. Đây là kiểm chứng phần mềm và bằng chứng số liệu, không phải chứng nhận hiệu quả phát hiện mọi backdoor.

Phúc cần gửi kết quả trigger trên file để nhận xét phần binary. Quân cần ghép đúng một bản Word rồi xuất PDF kiểm bố cục. Phú cần hoàn tất rà tài liệu tham khảo. Trong lúc chưa có kết quả binary, Abstract phải giữ giới hạn feature-space.
