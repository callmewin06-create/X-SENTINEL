# X SENTINEL research revision content

These sections and tables are for the paper editor to integrate into the canonical manuscript. Table numbers should follow the final manuscript order. The original 54 configurations remain the primary benchmark; additional seed and training-defense experiments are reported separately.

## Suggested title and abstract

Suggested title: Feature-View Attribution Concentration as a Per-Input Backdoor Signal for Static PE Classifiers.

X-SENTINEL studies per-input backdoor suspicion in LightGBM static malware classifiers using view attribution concentration and Behavioral-gated SHAP. All trigger experiments reported here operate in feature space. The primary Reduced setting requires the suspicious model and disjoint trusted benign reference and calibration pools, while a supplemental Full setting additionally uses a clean Behavioral classifier. We evaluate 54 frozen model/attack configurations on two EMBER schemas and compare calibrated detection with a signed-SHAP Isolation Forest baseline and clean Shadow model. Retrospective low-FPR comparisons, two additional EMBER2024 seed attempts, clean-data budgets and a small training-data sanitization experiment clarify the effects of defender access and evaluation conditions. Cross-view triggers and bounded multiview adaptation expose substantial weaknesses in view-concentration signals. A clean Shadow model remains a strong comparator when trusted labelled training data are available. These findings support a limited interpretation of attribution signals under restricted access rather than a general claim of backdoor robustness.

## Contributions and scope

Our contributions are:

- A study of view attribution concentration and Behavioral-gated SHAP as per-input suspicion signals under restricted defender access.
- Calibrated evaluation across 54 frozen model/attack configurations on two EMBER schemas, supplemented by a signed-SHAP novelty baseline and low-FPR comparisons.
- Evidence that distributed and multiview adaptive vector modifications undermine these signals.
- An analysis of clean-data access, training-data sanitization, and variability across additional model seeds.

All experiments in this package operate in feature space. We investigate suspicion signals for a supplied LightGBM malware classifier. Reduced requires access to the suspicious model, 500 trusted benign reference samples and 2000 disjoint benign calibration samples. Full additionally uses a Behavioral classifier trained on trusted labelled data. A Shadow comparator uses a trusted full-feature classifier. Trusted training data contain both benign and malware examples; trusted does not mean benign-only. We position Reduced as the primary restricted-access setting and Full as a supplemental resource-rich comparison. Source IDs are reused across fixed model configurations, and each run contributes equal weight to macro summaries.

The evaluator's clean model defines clean-original eligibility but is not supplied to Reduced during inference. The Shadow comparator explicitly grants access to a clean classifier. Successful-eligible inputs are malware identified by the evaluator's clean model before modification and evaded by the suspicious classifier after modification. Shadow evaluates its clean classifier on the modified input, so its gap is closely related to this positive-group definition whenever the clean classifier resists the trigger. It is not an exact identity because eligibility uses the original input. This relationship and the extra model access must be considered when interpreting its high recall.

## Low FPR comparison

We retain the original deployment thresholds calibrated on benign calibration data. Separately, we report the highest attainable TPR at an empirical final-set FPR no greater than 1%, keeping tied scores together, and standardized partial AUC over FPR 0–1%. The standardized statistic uses sklearn max_fpr=0.01 and is not a raw area. These final-set operating points are retrospective comparisons, not newly validated deployment thresholds. Each method is compared on the same source IDs and attack eligibility masks within a run.

| Dataset | Cohort | Method | Runs | TPR at cap % | Actual FPR % | Standardized pAUC |
| --- | --- | --- | --- | --- | --- | --- |
| EMBER2018 | restricted | SHAP-IF | 12 | 0.16 | 0.99 | 0.4978 |
| EMBER2018 | restricted | Shadow | 12 | 99.99 | 1.00 | 0.9995 |
| EMBER2018 | restricted | Full | 12 | 44.72 | 0.96 | 0.6797 |
| EMBER2018 | restricted | Reduced | 12 | 37.69 | 0.87 | 0.6713 |
| EMBER2024 | cross | SHAP-IF | 9 | 0.02 | 1.00 | 0.4975 |
| EMBER2024 | cross | Shadow | 9 | 99.60 | 1.00 | 0.9907 |
| EMBER2024 | cross | Full | 9 | 6.01 | 0.94 | 0.5179 |
| EMBER2024 | cross | Reduced | 9 | 0.0023 | 0.98 | 0.4975 |
| EMBER2024 | restricted | SHAP-IF | 3 | 0.04 | 1.00 | 0.4976 |
| EMBER2024 | restricted | Shadow | 3 | 99.98 | 1.00 | 0.9990 |
| EMBER2024 | restricted | Full | 3 | 60.13 | 0.95 | 0.7684 |
| EMBER2024 | restricted | Reduced | 3 | 52.82 | 0.97 | 0.6838 |

TPR above is measured on successful-eligible triggered malware. Actual FPR can be below 1% because tied scores cannot always attain exactly 1%. CSVs also contain paired-new-evasion and all-triggered groups. The clean Shadow model remains a material comparator; the original availability of 200000 trusted labelled fit records must be stated when interpreting Full.

## Signed SHAP outlier baseline

For each suspicious model, we fit Isolation Forest on signed native SHAP vectors from the 500 benign reference samples, excluding the bias column. We fix 200 trees, max_samples=256, max_features=1.0, no bootstrap and random_state=17. Larger anomaly scores are obtained by negating score_samples. The decision threshold is selected independently on 2000 benign calibration samples with the same strict score greater than threshold convention. No hyperparameters are selected using final-set recall. We additionally score the same malware before the trigger modification; this control helps distinguish malware–benign differences from trigger-specific sensitivity. Original-malware alert rate is not benign FPR. This is a simple reference-only novelty baseline, not an exhaustive search over SHAP defenses.

## Cross and bounded multiview adaptation

For EMBER2018 Cross, confirmation clean-model triggered ASR ranges from 91.51% to 95.49%. Net paired gain ranges from 4.18 to 8.49 percentage points, below the prespecified 20-point threshold. High poisoned-model ASR alone therefore does not establish a strong additional poisoning effect. Separate CSVs report paired new and lost evasions in confirmation and final pools.

| Dataset | Runs | Clean triggered ASR % | Poisoned triggered ASR % | Paired new evasion % | Paired lost evasion % | Net gain pp |
| --- | --- | --- | --- | --- | --- | --- |
| EMBER2018 | 9 | 92.95 | 99.87 | 6.92 | 0.00 | 6.92 |
| EMBER2024 | 9 | 17.87 | 99.56 | 81.69 | 0.00 | 81.69 |

This table uses the confirmation pool. Paired new evasion counts eligible sources evaded by the poisoned classifier but not by the clean classifier after the same trigger; net gain subtracts the converse losses. Their equality in these runs reflects zero observed paired losses, not interchangeable definitions.

We also conduct bounded multiview adaptation on 24 previously confirmed models. For each dataset, 100 malware source IDs are selected by lexical ID order before querying outcomes. The procedure retains the original trigger and permits at most eight additional coordinates per view, with empirical values from the benign selection pool. Each input receives at most 32 attacker queries, including the initial query. The objective uses only the main probability and Reduced score; Full is evaluated afterward. The source IDs are reused across runs, so the 2400 model-input evaluations are not 2400 independent malware samples. Joint evasion means classifier evasion and no Reduced alert among clean-original eligible samples.

| Dataset | Cohort | Runs | Joint evasion before % | Joint evasion after % | Change pp |
| --- | --- | --- | --- | --- | --- |
| EMBER2018 | restricted | 12 | 44.25 | 59.50 | 15.25 |
| EMBER2024 | cross | 9 | 100.00 | 100.00 | 0.00 |
| EMBER2024 | restricted | 3 | 36.77 | 45.02 | 8.25 |

Cross inputs already jointly evading the model and detector are retained without additional search. Search failure under this finite budget cannot establish adaptive robustness. These outcomes motivate reporting Cross and adaptive failures in the main results.

## EMBER2024 additional seeds

We predeclare seeds 59 and 71, retain the original legacy_rare selector, spread Structural geometry and 2% poisoning rate of all fit records, and preserve the original screening cutoffs. Both successful and unsuccessful repetitions are retained. Reference/calibration batch conventions and final batches 128 match the primary implementation. No seed is substituted after inspecting outcomes.

| Seed | Origin | Confirmed | Confirmation ASR % | Reduced recall % | Reduced FPR % | Full recall % | Full FPR % |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 17 | original | True | 57.46 | 48.85 | 0.85 | 62.79 | 0.61 |
| 29 | original | True | 55.81 | 48.86 | 0.81 | 63.67 | 0.71 |
| 43 | original | True | 52.18 | 47.27 | 0.67 | 52.79 | 1.16 |
| 59 | additional | True | 53.33 | 54.30 | 0.79 | 60.06 | 0.93 |
| 71 | additional | False | 49.82 | 45.94 | 0.67 | 52.90 | 0.98 |

There are five attempted seed repetitions in this condition and 4 that satisfy the original development and confirmation criteria. Seed 71 has confirmation ASR 49.82%, below the 50% cutoff. This threshold miss is not evidence of classifier safety. The supplementary variability CSV reports all five attempts and the confirmed subset separately. Fixed-model bootstrap intervals measure source-sample uncertainty conditional on the selected models, not variability over future trained models. Additional seeds in spread 2% do not broaden the evaluated trigger families.

Within the four confirmed seed attempts, Reduced recall has mean 49.82%, sample SD 3.08 percentage points and range 47.27–54.30%. Full recall has mean 59.83%, sample SD 4.94 points and range 52.79–63.67%. These use the original-style calibration thresholds, not the retrospective final-set thresholds.

## Clean data budget

We compare1000, 5000, 10000, 50000 and 200000 trusted labelled fit records. Subsets are nested, class-balanced and identical for Behavioral and Shadow training at each seed and budget. Suspicious models, reference/calibration pools, evaluation IDs and attack groups remain fixed. The 200000 endpoint reuses the original models and is checked against original Full scores. For the budget experiment, only the Behavioral auxiliary model consumed by the Full formula is trained; cached view concentration is unchanged. The 500 benign reference and 2000 benign calibration records are outside the plotted fit budget. Shadow does not require the 500 rank-reference records. Figures and the complete budget summary are supplied separately.

At the smallest tested budget of 1000 labelled fit records, Full attains mean low-FPR TPR of 33.60% and 56.24% on the 2018 and 2024 restricted cohorts, compared with 16.90% and 51.29% for Shadow. However, Full at this budget falls below Reduced on EMBER2018. With 200000 trusted fit records, Shadow dominates Full on both cohorts. The curves therefore support a conditional resource comparison, not a general advantage for Full. The original 150-round Behavioral and 500-round Shadow training settings are retained. Matching fit subsets does not equalize training compute or every use of trusted information: Full also consumes500 benign rank-reference records, which Shadow does not use for training.

## Training data sanitization context

Severi et al. evaluate training-data filtering in reduced feature spaces, including Isolation Forest [USENIX Security2021, Section 7](https://www.usenix.org/system/files/sec21-severi.pdf). Our two-cell supplementary experiment is an adaptation, not a replication of their reported numbers. Unlike Reduced, it grants access to the potentially poisoned labelled training set and permits retraining.

We select 32 features by mean absolute SHAP from the suspicious model on 500 trusted benign reference records, fit Isolation Forest on benign-labelled training rows in that reduced raw-feature space, and remove the highest-scoring5% of those rows. A separate fixed RNG20261027 selects a matching random-removal control. Poison identities are used only to count removed poisons after the mask is fixed. Both classifiers are retrained with the original 500-round parameters. The study fixes seed 17 and spread 2% on each dataset; it is not a54-cell training-defense benchmark.

| Dataset | Method | Removed | Poisons removed | Unpoisoned removed | ASR before % | ASR after % | Clean-test accuracy % |
| --- | --- | --- | --- | --- | --- | --- | --- |
| EMBER2018 | IF_top32 | 5000 | 977 | 4023 | 97.81 | 95.75 | 95.93 |
| EMBER2018 | random_control | 5000 | 169 | 4831 | 97.81 | 98.86 | 96.08 |
| EMBER2024 | IF_top32 | 5000 | 1845 | 3155 | 59.39 | 35.84 | 97.31 |
| EMBER2024 | random_control | 5000 | 169 | 4831 | 59.39 | 59.79 | 97.36 |

ASR uses the same clean-original eligible malware denominator before and after retraining. Accuracy is measured on the original labelled final pool. Removal counts and residual ASR should be interpreted together with utility; a training sanitization result is not a per-input detection recall.

## Consolidated limitations and technical corrections

All new analyses reuse previously observed benchmark pools; the old fresh_validation directory is not a new unseen holdout for this revision. Cross and bounded adaptive outcomes limit the claimed robustness. Limited seed counts and a single condition for additional2024 repetitions restrict generalization. Binary-trigger feasibility and detector efficacy on executable files require separate evidence from the binary task. BODMAS classification results have no verified trigger labels. A benign fixture called malware is a classification error, not automatically a poisoning effect. Operational timing results from different input sets and execution scopes should not be presented as a measured speedup. We do not attribute calibration-to-final FPR differences solely to ties or distribution shift without further evidence.

Use descriptive component names consistently: VMC for M3 view mass concentration, BGS for M4 Reduced Behavioral-gated SHAP and BPG for M4 Full Behavioral probability gap. Historical code keys remain unchanged. Move Streamlit, database, restore, upload-limit and regression-test details to the technical appendix. Preserve the poisoning denominator as all fit records:4000/200000=2%, equivalent to 4% of 100000 benign fit records.
