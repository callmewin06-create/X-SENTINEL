# Bàn giao phần nghiên cứu ngày 27 tháng 10 năm 2026

Gói này dành cho bạn duyệt và Quân ghép vào bản Word chính. Các kết quả mới bổ sung bằng chứng và sửa cách so sánh; chúng không làm cho detector tự nhiên chống được Cross.

- SHAP baseline: hoàn tất54 cấu hình gốc; có đối chứng malware chưa trigger.
- Cùng mức báo nhầm: bảng so sánh có tỷ lệ thật đạt được, không tách các điểm bằng nhau để ép đủ 1%.
- Adaptive nhiều view: hoàn tất24 model,100 source ID mỗi dataset. Một mẫu xuất hiện ở nhiều model; không gọi2400 lượt là2400 file độc lập.
- EMBER2024: đã chạy thêm seed 59 và71. Tổng5 lượt thử ở spread2%,4 lượt đạt tiêu chí. Giữ cả seed không đạt.
- Ngân sách sạch: đủ 5 mức trên cả2 dataset và3 seed. Mẫu sạch ở đây là mẫu có nhãn đáng tin, gồm cả malware và benign; không phải toàn file lành.
- Phòng thủ tập train:2 cấu hình, có IF lọc dữ liệu và đối chứng loại ngẫu nhiên độc lập, rồi huấn luyện lại. Không suy thành đã chạy trên54 cấu hình.

## Bạn gửi cho Quân

PAPER_INSERTS_EN.md chứa nội dung tiếng Anh và bảng chính; cácCSV giữ số đầy đủ; figures/ chứa hình. Quân dùng một bản Word chính, đặt lại số bảng/hình sau khi ghép. Gói này không ghi đè bản Word nhóm đang chỉnh.

## Các điểm phải giải thích đúng

1. Full cần nhiều dữ liệu sạch hơn Reduced. Shadow vẫn phải được trình bày cùng tài nguyên và cùng mức báo nhầm, dù kết quả bất lợi cho Full.
2. Tỷ lệ phát hiện chỉ tính trên nhóm được định nghĩa rõ; không gọi recall là accuracy.
3. Thêm seed không bảo đảm thêm lượt đạt yêu cầu. Lượt không đạt vẫn là dữ liệu nghiên cứu.
4. Bộ dữ liệu final và fresh cũ đã được xem trước đây. Những phép so sánh mới là phân tích bổ sung trên benchmark cố định.
5. Kết quả mẫu BODMAS không chứng minh phát hiện backdoor thực tế khi không có nhãn trigger.

## Chỉnh sửa trong lúc triển khai

Hai thư mục cũ chỉ giữ để truy vết, không dùng làm bảng cuối: ember2024_seeds/ được thay bằng ember2024_seeds_v2/ để thống nhất cách chấm theo lô với primary; training_defense/ có đối chứng ngẫu nhiên sai do dùng chung dòng số ngẫu nhiên với bước chọn mẫu đầu độc, được thay bằng training_defense_v2/. Model và trigger của hai seed được giữ nguyên khi sửa cách chấm. Đối chứng ngẫu nhiên mới dùng seed 20261027, không chọn seed theo kết quả cuối. Kiểm thử đã được bổ sung để ngăn lỗi này.

## Việc đang chờ

Phúc chưa gửi bằng chứng trigger trên file. Quân chưa gửi bản Word ghép cuối. Phú phụ trách rà toàn bộ nguồn tham khảo. Vì vậy review_response_status.csv phân biệt phần nghiên cứu đã có kết quả với các phần đang chờ tích hợp; không đánh dấu toàn bài đã sửa xong.

## Chạy lại

Chạy từ thư mục gốc project bằng môi trường .venv, với dữ liệu và các model gốc có sẵn. Thứ tự: run_shap_outlier_2026_10_27.py; run_multiview_adaptive_2026_10_27.py; run_ember2024_seeds_2026_10_27.py; run_training_defense_2026_10_27.py; run_clean_budget_2026_10_27.py; analyze_teacher_feedback_2026_10_27.py; audit_teacher_revision_2026_10_27.py; build_teacher_handoff_2026_10_27.py. Các chương trình chạy nghiên cứu nằm trong scripts/. Không đổi tham số trong thư mục kết quả đã khóa; dùng namespace mới khi đổi phương pháp.
